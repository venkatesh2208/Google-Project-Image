#!/bin/bash

protoc --python_out=. messages.proto
